ladderplot <-
function (x, ...) 
    UseMethod("ladderplot")

