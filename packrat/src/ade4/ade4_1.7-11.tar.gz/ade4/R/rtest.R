"rtest" <- function (xtest, ...) {
    UseMethod("rtest")
}
