# shinyalert 1.0

2018-02-12

Initial release
